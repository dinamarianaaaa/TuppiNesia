<?php
session_start();
session_destroy();
Location ('header:site_url()');
?>